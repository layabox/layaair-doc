﻿using UnityEngine;
using UnityEditor;
//using NUnit.Framework;


using System.IO;

using System;
using System.Runtime.InteropServices;

public class LayaPlugin : EditorWindow
{
    // From c++ Dll (unmanaged)
    //[DllImport("LayaClassLibrary", EntryPoint = "getData")]//[DllImport(@"c:\lemma.dll")]
    //public static extern void LayaToolsDataManager_getData(bool settingOnlySelected, bool settingAllScene);//, [MarshalAs(UnmanagedType.I4)]int size
   
    private static string windowDisplay = null;
    string pathBase = null;
    bool settingOnlySelected = false;
    bool settingAllScene = true;
    int indexPopup;
    
    [MenuItem("LayaTools/Export Scene (输出场景)")]
    private static void ExportScene()
    {
        LayaPlugin window = (LayaPlugin)EditorWindow.GetWindowWithRect(typeof(LayaPlugin), new Rect(Screen.width / 2, Screen.height / 2, 500, 110), true);
        window.Show();
        windowDisplay = "Export Scene (输出场景)";
    }
    [MenuItem("LayaTools/About")]
    private static void About()
    {
        LayaPlugin window = (LayaPlugin)EditorWindow.GetWindowWithRect(typeof(LayaPlugin), new Rect(Screen.width / 2, Screen.height / 2, 220, 200), true);
        window.Show();
        windowDisplay = "About";
    }
    void OnGUI()
    {
        if (windowDisplay == "Export Scene (输出场景)")
            windowShowExportScene();
        else if (windowDisplay == "About")
            windowShowAbout();
     
    }
    void windowShowAbout()
    {
        string pathProgram = Application.dataPath;

        // label
        GUILayout.Label("LayaExporter About", EditorStyles.boldLabel);

        Rect GUILayoutRect = GUILayoutUtility.GetLastRect();

        // logo
        GUILayout.BeginHorizontal();
        WWW w = new WWW("file://" + pathProgram + "/LayaPlugin/layabox.png");
        w.LoadImageIntoTexture(w.texture);
        GUI.DrawTexture(new Rect((int)(220*0.5-128*0.5), GUILayoutRect.y+20, 128, 128), w.texture);
        GUILayout.EndHorizontal();
         
        // copyright
        GUILayout.BeginArea(new Rect(2, 128+20+10, 220, 220));
        GUILayout.Label("Layabox 搜游网络科技 Co., Ltd", EditorStyles.whiteLabel);
        GUILayout.Label("Copyright \u00A9 2016 Laya Technologies", EditorStyles.whiteLabel);
        GUILayout.EndArea();

    }
    void windowShowExportScene()
    {
        int contentWidth;
        //string pathProgram = Application.dataPath;

        // label
        GUILayout.Label("LayaExporter Settings", EditorStyles.boldLabel);

        // check out
        GUILayout.BeginHorizontal();
        if(EditorGUILayout.Toggle("Selected elements only", settingOnlySelected))  {
            settingOnlySelected = true;
            settingAllScene = false;
        }
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        if(EditorGUILayout.Toggle("All current scene", settingAllScene)) {
            settingOnlySelected = false;
            settingAllScene = true;
        }
        GUILayout.EndHorizontal();

        // browser window
        GUILayout.BeginHorizontal();
        EditorGUILayout.TextField("Save Path", pathBase);
        contentWidth = (int)GUI.skin.GetStyle("Button").CalcSize(new GUIContent("Browse")).x;
        if (GUILayout.Button("Browse", GUILayout.Width(contentWidth) )) {
            pathBase = EditorUtility.SaveFolderPanel("Choose save folder", "Assets", "");
            //string[] files = Directory.GetFiles(pathBase);
            //Debug.Log(pathBase);
        }
        GUILayout.EndHorizontal();

        // browse button
        GUILayout.BeginHorizontal();
        contentWidth = (int)GUI.skin.GetStyle("Button").CalcSize(new GUIContent("Export")).x;
        if( GUILayout.Button("Export", GUILayout.Width(contentWidth))) {
            Debug.Log(" -- LayaTools.DataManager -- ");
          
            if (pathBase != null)
            {
                LayaTools.DataManager.SAVEPATH = pathBase;
                LayaTools.DataManager.STEPUNIT = 1.0f;
                LayaTools.DataManager.BONESMAX = 24;
                LayaTools.DataManager.getData(settingOnlySelected, settingAllScene);
            }
            //LayaToolsDataManager_getData(settingOnlySelected, settingAllScene);
            //w.Dispose();
            //w = null;
            GUIUtility.ExitGUI();
        }
        GUILayout.EndHorizontal();
    }

}
