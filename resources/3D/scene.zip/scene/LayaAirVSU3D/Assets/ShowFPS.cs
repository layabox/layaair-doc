using UnityEngine;
using System.Collections;

public class ShowFPS : MonoBehaviour {

    public float f_UpdateInterval = 0.5F;

    private float f_LastInterval;

    private int i_Frames = 0;

    private float f_Fps;

    void Start() 
    {
		//Application.targetFrameRate=60;

        f_LastInterval = Time.realtimeSinceStartup;

        i_Frames = 0;
    }

    void OnGUI() 
    {
        GUIStyle bb = new GUIStyle();
        bb.normal.background = null;    //�������ñ�������
        bb.normal.textColor = new Color(1, 1, 0);   //����������ɫ��
        bb.fontSize = 60;       //��Ȼ������������ɫ

        GUI.Label(new Rect(Screen.width/2- 200/2, Screen.height / 2 - 200/2, 200, 200), "FPS:" + f_Fps.ToString("f2"), bb);
    }

    void Update() 
    {
        ++i_Frames;

        if (Time.realtimeSinceStartup > f_LastInterval + f_UpdateInterval) 
        {
            f_Fps = i_Frames / (Time.realtimeSinceStartup - f_LastInterval);

            i_Frames = 0;

            f_LastInterval = Time.realtimeSinceStartup;
        }
    }
}
