#if defined(GL_FRAGMENT_PRECISION_HIGH)// 原来的写法会被我们自己的解析流程处理，而我们的解析是不认内置宏的，导致被删掉，所以改成 if defined 了
	precision highp float;
	precision highp int;
#else
	precision mediump float;
	precision mediump int;
#endif

#include "Lighting.glsl";
#include "Shadow.glsl"
#include "PBRFSInput.glsl";
#include "LayaPBRBRDF.glsl";
#include "GlobalIllumination.glsl";
#include "PBRCore.glsl";

#define SHADER_NAME CMPBR.FS

#ifdef SKINMASK
    uniform sampler2D u_CMMask;
#endif

#ifdef CMMRSTEX
	uniform sampler2D u_MRSTex;
#endif
uniform vec3 u_hsv;

#ifdef CMMETALLIC
	uniform sampler2D u_CMMetallicTex;
#endif
#ifdef CMROUGHNESS
	uniform sampler2D u_CMRoughnessTex;
#endif

#ifdef blusher
	uniform vec4 u_blusherVec;
	uniform vec3 u_blusherHsv;
	uniform sampler2D u_blusher;
#endif

#ifdef eyelid
	uniform vec4 u_eyelidVec;
	uniform vec3 u_eyelidHsv;
	uniform sampler2D u_eyelid;
#endif

#ifdef eyeline
	uniform vec4 u_eyelineVec;
	uniform vec3 u_eyelineHsv;
	uniform sampler2D u_eyeline;
#endif

#ifdef eyeshadow
	uniform vec4 u_eyeshadowVec;
	uniform vec3 u_eyeshadowHsv;
	uniform sampler2D u_eyeshadow;
#endif

#ifdef freckle
	uniform vec4 u_freckleVec;
	uniform vec3 u_freckleHsv;
	uniform sampler2D u_freckle;
#endif

#ifdef lipstick
	uniform vec4 u_lipstickVec;
	uniform vec3 u_lipstickHsv;
	uniform sampler2D u_lipstick;
#endif

#ifdef tatoo
	uniform vec4 u_tatooVec;
	uniform vec3 u_tatooHsv;
	uniform sampler2D u_tatoo;
#endif



vec3 rgb2hsv(vec3 c) {
	vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
	vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
	vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
	float d = q.x - min(q.w, q.y);
	float e = 0.0001;
	return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

vec3 hsv2rgb(vec3 c) {
	vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
	vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
	return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

vec3 GammaToLinear( in vec3 value, in float gammaFactor ) {
	vec3 sRGB = value.rgb;
	sRGB = sRGB * (sRGB * (sRGB * 0.305306011 + 0.682171111) + 0.012522878);
	return vec3(sRGB);
}

vec3 LinearToGamma(in vec3 value, in float gammaFactor) {
	vec3 linRGB = value.rgb;
	linRGB = max(linRGB, vec3(0.0, 0.0, 0.0));
	vec3 gamma;
	gamma.r = 1.055 * pow(linRGB.r, 0.416666667)  - 0.055;
	gamma.g = 1.055 * pow(linRGB.g, 0.416666667)  - 0.055;
	gamma.b = 1.055 * pow(linRGB.b, 0.416666667)  - 0.055;
	gamma = max( gamma, vec3(0.0, 0.0, 0.0) );
	return gamma;
}

vec3 mapTexelToLinear( vec3 value ) {
    return GammaToLinear( value, float( 2.0 ) );
}

vec3 applyHSV(vec3 color, vec3 deltaHSV) {
	if (deltaHSV.x != 0.0) {
		vec3 hsv = rgb2hsv(color.rgb);
		hsv.x += deltaHSV.x;
		if (hsv.x > 6.0) {
			hsv.x = hsv.x - 6.0;
		}
		else if (hsv.x < 0.0) {
			hsv.x = hsv.x + 6.0;
		}
		color.rgb = hsv2rgb(hsv);
	}
	if (deltaHSV.y != 0.0) {
		float c_max = max(color.r, max(color.g, color.b));
		float c_min = min(color.r, min(color.g, color.b));
		float delta = c_max - c_min;
		if (delta != 0.0) {
			float v = c_max + c_min;
			float l = v * 0.5;
			float s = l < 0.5 ? (delta / v) : ((delta) / (2.0 - v));
			if (deltaHSV.y >= 0.0) {
				float alpha = (deltaHSV.y + s) >= 1.0 ? s : (1.0 - deltaHSV.y);
				alpha = 1.0 / alpha - 1.0;
				color.rgb = color.rgb + (color.rgb - l) * alpha;
			}
			else {
				float alpha = deltaHSV.y;
				color.rgb = l + (color.rgb - l) * (1.0 + alpha);
			}

		}

	}
	if (deltaHSV.z != 0.0) {
		color.rgb = deltaHSV.z > 0.0 ? (color.rgb * (1.0 - deltaHSV.z) + deltaHSV.z) : (color.rgb + color.rgb * deltaHSV.z);
	}

	color = LinearToGamma(color, 2.0);
	return color;
}
#ifdef _ABS_HSV_ON
	uniform vec3 u_disneyhsv;
	mediump vec3 Blend2(mediump vec3 left, mediump vec3 right, mediump float pos) {
		return vec3(left.r * (1.0-pos) + right.r * pos, left.g * (1.0-pos) + right.g * pos, left.b * (1.0-pos) + right.b * pos);
	}
	mediump vec3 Blend3(mediump vec3 left, mediump vec3 main, mediump vec3 right, mediump float pos) {
        return pos < 0.0 ?  Blend2(left, main, 1.0 + pos) : Blend2(main, right, pos);
    }
	mediump vec3 HSVColorizeABSCore(mediump vec3 mainColor, mediump float deltaH, mediump float deltaS, mediump float deltaV) {
        mediump vec3 hueRGB = hsv2rgb(vec3(deltaH, 1.0, 1.0));
        mediump float saturation = deltaS;
        mediump float lightness = clamp(deltaV, -1.0, 1.0);
        mediump float value = rgb2hsv(mainColor.rgb).z;
        mediump vec3 cc = Blend2(vec3(0.5, 0.5, 0.5), hueRGB, saturation);
        return lightness >= 0.0 ? vec3(Blend3(vec3(0.0, 0.0, 0.0), cc, vec3(1.0, 1.0, 1.0), 2.0 * (1.0 - lightness) * (value - 1.0) + 1.0)) :
        vec3(Blend3(vec3(0.0, 0.0, 0.0), cc, vec3(1.0, 1.0, 1.0), 2.0 * (1.0 + lightness) * (value) - 1.0));
    }
	mediump vec3 HSVColorizeABS(mediump vec3 mainColor) {
		vec3 result = HSVColorizeABSCore(mainColor, u_disneyhsv.x, u_disneyhsv.y, u_disneyhsv.z);
		return result;
	}

#endif

#ifdef _REL_HSV_ON
	mediump vec3 HSVColorizeRELCore(mediump vec3 color, vec3 deltaHSV) {
		return applyHSV(color, deltaHSV);
	}
	mediump vec3 HSVColorizeREL(mediump vec3 mainColor, vec3 hsv) {
		#if defined(_ABS_HSV_ON)
            mainColor = HSVColorizeABS(mainColor);
        #endif
		mediump vec3 result = HSVColorizeRELCore(mainColor, hsv);
		return result;
	}
#endif

mediump vec3 applyMakeup(vec3 mc, vec2 uv, sampler2D beautyTex, vec4 beauty, vec3 beautyHsv2) {
	vec2 cl = vec2(beauty.x, beauty.y);
	vec2 cs = beauty.zw;
	if(uv.x >= cl.x && uv.x <= (cl.x + cs.x) && uv.y >= cl.y && uv.y <= (cl.y + cs.y) )
	{
		vec2 localUV = vec2((uv.x - cl.x) / (cs.x) ,(uv.y - cl.y) / (cs.y) );
		localUV.y = 1.0 - localUV.y;
		vec4 c = texture2D(beautyTex, localUV);
		c.rgb = applyHSV(mapTexelToLinear(c.rgb), beautyHsv2);
		// mc = mc * ( 1.0 - c.a) + vec3(c.rgb) * c.a;
		mc = mix(mc, c.rgb, c.a);
	}
	return mc;
}



FragmentCommonData cmshowSpecularSetup(vec2 uv) {
	mediump vec4 specGloss = specularGloss(uv);
    mediump vec3 specColor = specGloss.rgb;
    mediump float smoothness = specGloss.a;

    mediump float oneMinusReflectivity;

	vec3 color = albedo(uv);
	#ifdef SKINMASK
		if (texture2D(u_CMMask, vec2(uv.x, uv.y)).r > 0.1) {
			color = applyHSV(mapTexelToLinear(color), u_hsv);
		}
	#else
		#ifdef CMFACE
			color = applyHSV(mapTexelToLinear(color), u_hsv);
		#endif
	#endif

    mediump vec3 diffColor = energyConservationBetweenDiffuseAndSpecular (color, specColor, /*out*/ oneMinusReflectivity);

    FragmentCommonData o;
    o.diffColor = diffColor;
    o.specColor = specColor;
    o.oneMinusReflectivity = oneMinusReflectivity;
    o.smoothness = smoothness;
    return o;
}

FragmentCommonData cmshowMetallicSetup(vec2 uv) {

	mediump float oneMinusReflectivity;
	vec3 color = albedo(uv);
	#ifdef SKINMASK

		mediump float skinFactor = 0.0;

		if (texture2D(u_CMMask, vec2(uv.x, uv.y)).r > 0.1) {
			// color = applyHSV(mapTexelToLinear(color), u_hsv);
			skinFactor = 1.0;
			#ifdef _REL_HSV_ON
				color = HSVColorizeREL(mapTexelToLinear(color), u_hsv);
			#elif defined(_ABS_HSV_ON)
				color = HSVColorizeABS(mapTexelToLinear(color));
			#endif
		}
		mediump vec2 metallicGloss = getMetallicGloss(uv);

		#ifdef CMMETALLIC
			metallicGloss.x = texture2D(u_CMMetallicTex, uv).r;
		#endif
		#ifdef CMROUGHNESS
			metallicGloss.y = 1.0 - texture2D(u_CMRoughnessTex, uv).r;
		#endif

		#ifdef CMMRSTEX
			mediump vec3 mrs = texture2D(u_MRSTex, uv).rgb;
			mediump float metallic = mix(mrs.r, 1.0, metallicGloss.x);
			mediump float roughness = mix(mrs.g, 1.0, 1.0 - metallicGloss.y);
			metallic = mix(metallic, 0.0, skinFactor);
			mediump float smoothness = 1.0 - mix(roughness, 0.25, skinFactor);
		#else
			mediump float metallic = mix(metallicGloss.x, 0.0, skinFactor);
			mediump float smoothness = 1.0 - mix(1.0 - metallicGloss.y, 0.25, skinFactor);
		#endif
	#else
		mediump vec2 metallicGloss = getMetallicGloss(uv);
		// mediump vec4 specGloss = specularGloss(uv);
		#ifdef CMMRSTEX
			mediump vec3 mrs = texture2D(u_MRSTex, uv).rgb;
			mediump float metallic = mix(mrs.r, 1.0, metallicGloss.x);
			mediump float smoothness = 1.0 - mix(mrs.g, 1.0, 1.0 - metallicGloss.y);
			// mediump vec3 specColor = mix(vec3(mrs.b), vec3(1.0), specGloss.rgb);
		#else
			mediump float metallic = metallicGloss.x;
			mediump float smoothness = metallicGloss.y;
			// mediump vec3 specColor = specGloss.rgb;
		#endif

		#ifdef CMFACE
			color = applyHSV(mapTexelToLinear(color), u_hsv);
		#endif

		// #ifdef _REL_HSV_ON
        //     color = HSVColorizeREL(mapTexelToLinear(color), u_hsv);
		// #elif defined(_ABS_HSV_ON)
        //     color = HSVColorizeABS(mapTexelToLinear(color));
        // #endif
	#endif

	mediump vec3 specColor;
    // mediump vec3 diffColor = energyConservationBetweenDiffuseAndSpecular (color, specColor, /*out*/ oneMinusReflectivity);
	// color = LinearToGamma(color, 2.0);
	mediump vec3 diffColor = diffuseAndSpecularFromMetallic(color, metallic,/*out*/specColor,/*out*/oneMinusReflectivity);

	FragmentCommonData o;
	o.diffColor = diffColor;
	o.specColor = specColor;
	o.oneMinusReflectivity = oneMinusReflectivity;
	o.smoothness = smoothness;
	return o;
}

void main()
{
	vec2 uv;
	#if defined(ALBEDOTEXTURE)||defined(METALLICGLOSSTEXTURE)||defined(NORMALTEXTURE)||defined(EMISSIONTEXTURE)||defined(OCCLUSIONTEXTURE)||defined(PARALLAXTEXTURE)
		#ifdef PARALLAXTEXTURE
			uv = parallax(v_Texcoord0,normalize(v_ViewDirForParallax));
		#else
			uv = v_Texcoord0;
		#endif
	#endif

	mediump float alpha = getAlpha(uv);
	#ifdef ALPHATEST
		if(alpha<u_AlphaTestValue)
			discard;
	#endif

	#ifdef CMSPEC
		FragmentCommonData o = cmshowSpecularSetup(uv);
	#else
		FragmentCommonData o = cmshowMetallicSetup(uv);
	#endif

	#ifdef freckle
		o.diffColor = applyMakeup(o.diffColor, uv, u_freckle, u_freckleVec, u_freckleHsv);
	#endif

	#ifdef eyeshadow
		o.diffColor = applyMakeup(o.diffColor, uv, u_eyeshadow, u_eyeshadowVec, u_eyeshadowHsv);
	#endif

	#ifdef blusher
		o.diffColor = applyMakeup(o.diffColor, uv, u_blusher, u_blusherVec, u_blusherHsv);
	#endif

	#ifdef eyelid
		o.diffColor = applyMakeup(o.diffColor, uv, u_eyelid, u_eyelidVec, u_eyelidHsv);
	#endif

	#ifdef eyeline
		o.diffColor = applyMakeup(o.diffColor, uv, u_eyeline, u_eyelineVec, u_eyelineHsv);
	#endif

	#ifdef lipstick
		o.diffColor = applyMakeup(o.diffColor, uv, u_lipstick, u_lipstickVec, u_lipstickHsv);
	#endif

	#ifdef tatoo
		o.diffColor = applyMakeup(o.diffColor, uv, u_tatoo, u_tatooVec, u_tatooHsv);
	#endif


	vec3 binormal;
	vec3 tangent;
	#ifdef NORMALTEXTURE
		tangent = v_Tangent;
		binormal = v_Binormal;
	#endif

	vec3 normal = v_Normal;
	vec3 normalWorld = perPixelWorldNormal(uv,normal,binormal,tangent);//In FS if the normal use mediump before normalize will cause precision prolem in mobile device.
	vec3 eyeVec = normalize(v_EyeVec);
	vec3 posworld = v_PositionWorld;

	#ifdef TRANSPARENTBLEND
		o.diffColor=preMultiplyAlpha(o.diffColor,alpha,o.oneMinusReflectivity,/*out*/alpha);// shader relies on pre-multiply alpha-blend (srcBlend = One, dstBlend = OneMinusSrcAlpha)
	#endif

	mediump float occlusion = getOcclusion(uv);
	mediump vec2 lightMapUV;
	#ifdef LIGHTMAP
		lightMapUV=v_LightMapUV;
	#endif
	float perceptualRoughness = smoothnessToPerceptualRoughness(o.smoothness);
	float roughness = perceptualRoughnessToRoughness(perceptualRoughness);
	float nv = abs(dot(normalWorld, eyeVec));
	LayaGI gi =fragmentGI(o.smoothness,eyeVec,occlusion,lightMapUV,normalWorld,posworld);
	vec4 color = LAYA_BRDF_GI(o.diffColor,o.specColor,o.oneMinusReflectivity,o.smoothness,perceptualRoughness,roughness,nv,normalWorld,eyeVec,gi);
	
	float shadowAttenuation = 1.0;
	#ifdef LEGACYSINGLELIGHTING
		#ifdef DIRECTIONLIGHT
			#if defined(CALCULATE_SHADOWS)//shader中自定义的宏不可用ifdef 必须改成if defined
				#ifdef SHADOW_CASCADE
					vec4 shadowCoord = getShadowCoord(vec4(v_PositionWorld,1.0));
				#else
					vec4 shadowCoord = v_ShadowCoord;
				#endif
				shadowAttenuation=sampleShadowmap(shadowCoord);
			#endif
			LayaLight dirLight = layaDirectionLightToLight(u_DirectionLight,shadowAttenuation);
			color+= LAYA_BRDF_LIGHT(o.diffColor,o.specColor,o.oneMinusReflectivity,perceptualRoughness,roughness,nv,normalWorld,eyeVec,dirLight);
		#endif
	
		#ifdef POINTLIGHT
			shadowAttenuation = 1.0;
			LayaLight poiLight = layaPointLightToLight(posworld,normalWorld,u_PointLight,shadowAttenuation);
			color+= LAYA_BRDF_LIGHT(o.diffColor,o.specColor,o.oneMinusReflectivity,perceptualRoughness,roughness,nv,normalWorld,eyeVec,poiLight);
		#endif
		
		#ifdef SPOTLIGHT
			shadowAttenuation = 1.0;
			#if defined(CALCULATE_SPOTSHADOWS)//shader中自定义的宏不可用ifdef 必须改成if defined
				vec4 spotShadowcoord = v_SpotShadowCoord;
				shadowAttenuation = sampleSpotShadowmap(spotShadowcoord);
			#endif
		    LayaLight spoLight = layaSpotLightToLight(posworld,normalWorld,u_SpotLight,shadowAttenuation);
			color+= LAYA_BRDF_LIGHT(o.diffColor,o.specColor,o.oneMinusReflectivity,perceptualRoughness,roughness,nv,normalWorld,eyeVec,spoLight);
		#endif
	#else
	 	#ifdef DIRECTIONLIGHT
			for (int i = 0; i < MAX_LIGHT_COUNT; i++) 
			{
				shadowAttenuation = 1.0;
				if(i >= u_DirationLightCount)
					break;
				#if defined(CALCULATE_SHADOWS)//shader中自定义的宏不可用ifdef 必须改成if defined
					if(i == 0)
					{
						#ifdef SHADOW_CASCADE
							vec4 shadowCoord = getShadowCoord(vec4(v_PositionWorld,1.0));
						#else
							vec4 shadowCoord = v_ShadowCoord;
						#endif
						shadowAttenuation *= sampleShadowmap(shadowCoord);
					}
				#endif
				DirectionLight directionLight = getDirectionLight(u_LightBuffer,i);
				LayaLight dirLight = layaDirectionLightToLight(directionLight,shadowAttenuation);
			 	color+=LAYA_BRDF_LIGHT(o.diffColor,o.specColor,o.oneMinusReflectivity,perceptualRoughness,roughness,nv,normalWorld,eyeVec,dirLight);
			}
	 	#endif
		#if defined(POINTLIGHT)||defined(SPOTLIGHT)
			ivec4 clusterInfo =getClusterInfo(u_LightClusterBuffer,u_View,u_Viewport, v_PositionWorld,gl_FragCoord,u_ProjectionParams);
			#ifdef POINTLIGHT
				for (int i = 0; i < MAX_LIGHT_COUNT; i++) 
				{
					shadowAttenuation = 1.0;
					if(i >= clusterInfo.x)//PointLightCount
						break;
					PointLight pointLight = getPointLight(u_LightBuffer,u_LightClusterBuffer,clusterInfo,i);
					LayaLight poiLight = layaPointLightToLight(posworld,normalWorld,pointLight,shadowAttenuation);
					color+= LAYA_BRDF_LIGHT(o.diffColor,o.specColor,o.oneMinusReflectivity,perceptualRoughness,roughness,nv,normalWorld,eyeVec,poiLight);
				}
			#endif
			#ifdef SPOTLIGHT
				for (int i = 0; i < MAX_LIGHT_COUNT; i++) 
				{
					shadowAttenuation = 1.0;
					if(i >= clusterInfo.y)//SpotLightCount
						break;
					#if defined(CALCULATE_SPOTSHADOWS)//shader中自定义的宏不可用ifdef 必须改成if defined
						if(i == 0)
						{
							vec4 spotShadowcoord = v_SpotShadowCoord;
							shadowAttenuation= sampleSpotShadowmap(spotShadowcoord);
						}
					#endif
					SpotLight spotLight = getSpotLight(u_LightBuffer,u_LightClusterBuffer,clusterInfo,i);
					LayaLight spoLight = layaSpotLightToLight(posworld,normalWorld,spotLight,shadowAttenuation);
					color+= LAYA_BRDF_LIGHT(o.diffColor,o.specColor,o.oneMinusReflectivity,perceptualRoughness,roughness,nv,normalWorld,eyeVec,spoLight);
				}
			#endif
		#endif
	 #endif

	#ifdef EMISSION
		color.rgb += emission(uv);
	#endif

	#ifdef FOG
		float lerpFact=clamp((1.0/gl_FragCoord.w-u_FogStart)/u_FogRange,0.0,1.0);
		color.rgb=mix(color.rgb,u_FogColor,lerpFact);
	#endif
	
	gl_FragColor = vec4(color.rgb, alpha);
     
}