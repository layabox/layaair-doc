import { CameraMoveScript } from "./CameraMoveScript";
import { CmShowCharacterStruct, CmShowTool } from "./GLTFLoader/CmShowTool";
import Stage = Laya.Stage ;
import Stat = Laya.Stat ;
import Shader3D = Laya.Shader3D ;
import Scene3D = Laya.Scene3D ;
import Handler = Laya.Handler ;
import Vector3 = Laya.Vector3 ;
import Camera = Laya.Camera ;
import Vector4 = Laya.Vector4 ;
import Quaternion = Laya.Quaternion ;
import DirectionLight = Laya.DirectionLight ;
import Matrix4x4 = Laya.Matrix4x4 ;
import Loader = Laya.Loader ;
import Sprite3D = Laya.Sprite3D ;
import RenderableSprite3D = Laya.RenderableSprite3D ;

export class CmShowModeLoad {

    scene: Scene3D;
    camera: Camera;

    constructor() {
        Laya3D.init(0, 0);
        Laya.stage.scaleMode = Stage.SCALE_FULL;
        Laya.stage.screenMode = Stage.SCREEN_NONE;

        Stat.show();
        Shader3D.debugMode = true;

        // 初始化
        CmShowTool.init();
        /**
         * 厘米秀模型材质基于 pbr, 建议使用带 reflection texture 的场景
         */
        Scene3D.load("res/gltfMode/Scene/SampleScene.ls", Handler.create(this, this.onComplate));
    }

    // 厘米秀模型资源路径
    gltfFile: any = {
        // skeleton
        skeleton: {
            url: "res/gltfMode/gltf/cmshowtangent/skeleton.gltf",
            type: Loader.JSON
        },
        // face
        face: {
            url: "res/gltfMode/gltf/cmshowtangent/face.gltf",
            type: Loader.JSON
        },
        // eyes
        eyes: {
            url: "res/gltfMode/gltf/cmshowtangent/eyes.gltf",
            type: Loader.JSON
        },
        // eyebrow
        eyebrow: {
            url: "res/gltfMode/gltf/cmshowtangent/eyebrow.gltf",
            type: Loader.JSON
        },
        // eyelash
        eyelash: {
            url: "res/gltfMode/gltf/cmshowtangent/eyelash.gltf",
            type: Loader.JSON
        },
        // hair_app
        hair: {
            url: "res/gltfMode/gltf/beach/hair4/dress.gltf",
            type: Loader.JSON
        },
        // top
        top: {
            url: "res/gltfMode/gltf/beach/top3/dress.gltf",
            type: Loader.JSON
        },
        // bottom
        bottom: {
            url: "res/gltfMode/gltf/beach/bottom/dress.gltf",
            type: Loader.JSON
        },
        // socks
        socks: {
            url: "res/gltfMode/gltf/cmshowtangent/socks.gltf",
            type: Loader.JSON
        },
        // foot
        foot: {
            url: "res/gltfMode/gltf/beach/foot/dress.gltf",
            type: Loader.JSON
        },
        // backornament
        backornament: {
            url: "res/gltfMode/gltf/cmshowtangent/backornament.gltf",
            type: Loader.JSON
        }
    }

    // makeup资源路径
    makeupjson: any = {
        blusher: {
            cfg: "res/gltfMode/beautyResource/blusher/dress.json",
            tex: "res/gltfMode/beautyResource/blusher/beauty.png"
        },
        eyelid: {
            cfg: "res/gltfMode/beautyResource/eyelid/dress.json",
            tex: "res/gltfMode/beautyResource/eyelid/beauty.png"
        },
        eyeline: {
            cfg: "res/gltfMode/beautyResource/eyeline/dress.json",
            tex: "res/gltfMode/beautyResource/eyeline/beauty.png"
        },
        eyeshadow: {
            cfg: "res/gltfMode/beautyResource/eyeshadow/dress.json",
            tex: "res/gltfMode/beautyResource/eyeshadow/beauty.png"
        },
        freckle: {
            cfg: "res/gltfMode/beautyResource/freckle/dress.json",
            tex: "res/gltfMode/beautyResource/freckle/beauty.png"
        },
        lipstick: {
            cfg: "res/gltfMode/beautyResource/lipstick/dress.json",
            tex: "res/gltfMode/beautyResource/lipstick/beauty.png"
        },
        tatoo: {
            cfg: "res/gltfMode/beautyResource/tatoo/dress.json",
            tex: "res/gltfMode/beautyResource/tatoo/beauty.png"
        }
    }

    onComplate(scene: Scene3D) {
        Laya.stage.addChild(scene);
        this.scene = scene;
        scene.ambientColor = new Vector3(0.5408, 0.5408, 0.5408);
        scene.removeChildren();

        var camera: Camera = <Camera>scene.addChild(new Camera);
        this.camera = camera;
        this.camera.addComponent(CameraMoveScript);
        this.camera.clearColor = new Vector4(204 / 255, 204 / 255, 204 / 255);
        this.camera.transform.position = new Vector3(0.16478077542502395, 1.340013351640912, 2.095324968067005);
        this.camera.transform.rotation = new Quaternion(-0.06230654949548855, 0.02712381188794937, 0.0016939091725116163, 0.9976869866798648);

        // 添加 光照
        var lightColor: Vector3 = new Vector3(0.9137, 0.9098, 0.8863);
        //light
        var directionLight: DirectionLight = (<DirectionLight>this.scene.addChild(new DirectionLight()));
        directionLight.color = lightColor;
        //设置平行光的方向
        var mat: Matrix4x4 = directionLight.transform.worldMatrix;
        mat.setForward(new Vector3(0.0287, -0.1744, -0.9843));
        directionLight.transform.worldMatrix = mat;

        /**
         * 创建辅助对象，方便模型加载
         * 每一个厘米秀模型资源包括：
         *  1. 各部分模型gltf资源文件， 包括骨骼， 头， 身体等
         *  2. 个性化配置文件， 配置了模型的肤色， 脸部模型数据等个性化数据
         *  3. 装扮配置文件， 与装扮图片资源， 用于还原脸部装扮
         */
        var struct: CmShowCharacterStruct = new CmShowCharacterStruct();
        // gltf 模型资源对象
        struct.gltfURL = {};
        for (const key in this.gltfFile) {
            struct.gltfURL[key] = this.gltfFile[key];
        }
        // 个性化配置对象 / 可省略
        struct.customConfigURL = "res/gltfMode/face/face.json";
        // makeup装扮对象 / 可省略
        struct.makeupConfigURL = this.makeupjson;
        // 其他额外资源数组, 与gltf文件一同加载 / 可省略
        struct.extraRes = [];
        struct.extraRes.push("res/gltfMode/Aniamtor/dalaozuo-dalaozuo.lani");

        CmShowTool.LoadCharacter(struct, Handler.create(this, this.onLoadCharacter, [struct]));
    }

    /**
     * 
     * @param struct in 辅助对象， 记录部件与对应资源路径
     * @param sprite out 返回厘米秀模型根节点
     * @param renderableMap out 各部件与对应渲染节点map 
     */
    onLoadCharacter(struct: CmShowCharacterStruct, sprite: Sprite3D, renderableMap: Map<string, Array<RenderableSprite3D>>) {
        // 将节点添加到场景中
        this.scene.addChild(sprite);
    }
}

new CmShowModeLoad();