import CMPBRPS from "./shader/CMPBR.fs";
import CMPBRVS from "./shader/CMPBR.vs";
import CMPBRShadowCasterPS from "./shader/CMPBRShadowCaster.fs";
import CMPBRShadowCasterVS from "./shader/CMPBRShadowCaster.vs";


import Shader3D = Laya.Shader3D;
import VertexMesh = Laya.VertexMesh;
import SubShader = Laya.SubShader;
import BaseTexture = Laya.BaseTexture;
import ShaderDefine = Laya.ShaderDefine;
import Vector3 = Laya.Vector3;
import Vector4 = Laya.Vector4;
import PBRMaterial = Laya.PBRMaterial;
import PBRMetallicSmoothnessSource = Laya.PBRMetallicSmoothnessSource;
import PBRSpecularSmoothnessSource = Laya.PBRSpecularSmoothnessSource;

import PBRStandardMaterial = Laya.PBRStandardMaterial;

export class CmShowPBRMatrial extends PBRMaterial {

	/** @internal */
	static SHADERDEFINE_SMOOTHNESSSOURCE_ALBEDOTEXTURE_ALPHA: ShaderDefine;
	/** @internal */
	static SHADERDEFINE_SPECULARGLOSSTEXTURE: ShaderDefine;
	/** @internal */
	static SHADERDEFINE_METALLICGLOSSTEXTURE: ShaderDefine;
	/** @internal */
	static SHADERDEFINE_MRSTEXTURE: ShaderDefine;

	static SHADERDEFINE_REL_HSV_ON: ShaderDefine;
	static SHADERDEFINE_ABS_HSV_ON: ShaderDefine;
	static SHADERDEFINE_FACE: ShaderDefine;

	static SHADERDEFINE_CMMETALLIC: ShaderDefine;
	static SHADERDEFINE_CMROUGHNESS: ShaderDefine;

	/** @internal */
	static SHADERDEFINE_CMSPEC: ShaderDefine;

	/** @internal */
	static SPECULARTEXTURE: number = Shader3D.propertyNameToID("u_SpecGlossTexture");
	/** @internal */
	static SPECULARCOLOR: number = Shader3D.propertyNameToID("u_SpecularColor");
	/** @internal */
	static METALLICGLOSSTEXTURE: number = Shader3D.propertyNameToID("u_MetallicGlossTexture");
	/** @internal */
	static METALLIC: number = Shader3D.propertyNameToID("u_Metallic");


	static defaultMaterial: CmShowPBRMatrial;

	static SHADERDEFINE_SKINMASK: ShaderDefine;
	static SHADERDEFINE_blusher: ShaderDefine;
	static SHADERDEFINE_eyelid: ShaderDefine;
	static SHADERDEFINE_eyeline: ShaderDefine;
	static SHADERDEFINE_eyeshadow: ShaderDefine;
	static SHADERDEFINE_freckle: ShaderDefine;
	static SHADERDEFINE_lipstick: ShaderDefine;
	static SHADERDEFINE_tatoo: ShaderDefine;

	static CMMASK: number = Shader3D.propertyNameToID("u_CMMask");
	static CMSHVL: number = Shader3D.propertyNameToID("u_hsv");
	static CMDISNEYSHVL: number = Shader3D.propertyNameToID("u_disneyhsv");
	static CMMRSTEX: number = Shader3D.propertyNameToID("u_MRSTex");
	static CMMetallic: number = Shader3D.propertyNameToID("u_CMMetallicTex");
	static CMRoughness: number = Shader3D.propertyNameToID("u_CMRoughnessTex");

	static blusher: number = Shader3D.propertyNameToID("u_blusher");
	static eyelid: number = Shader3D.propertyNameToID("u_eyelid");
	static eyeline: number = Shader3D.propertyNameToID("u_eyeline");
	static eyeshadow: number = Shader3D.propertyNameToID("u_eyeshadow");
	static freckle: number = Shader3D.propertyNameToID("u_freckle");
	static lipstick: number = Shader3D.propertyNameToID("u_lipstick");
	static tatoo: number = Shader3D.propertyNameToID("u_tatoo");

	static blusherVec: number = Shader3D.propertyNameToID("u_blusherVec");
	static eyelidVec: number = Shader3D.propertyNameToID("u_eyelidVec");
	static eyelineVec: number = Shader3D.propertyNameToID("u_eyelineVec");
	static eyeshadowVec: number = Shader3D.propertyNameToID("u_eyeshadowVec");
	static freckleVec: number = Shader3D.propertyNameToID("u_freckleVec");
	static lipstickVec: number = Shader3D.propertyNameToID("u_lipstickVec");
	static tatooVec: number = Shader3D.propertyNameToID("u_tatooVec");

	static blusherHsv: number = Shader3D.propertyNameToID("u_blusherHsv");
	static eyelidHsv: number = Shader3D.propertyNameToID("u_eyelidHsv");
	static eyelineHsv: number = Shader3D.propertyNameToID("u_eyelineHsv");
	static eyeshadowHsv: number = Shader3D.propertyNameToID("u_eyeshadowHsv");
	static freckleHsv: number = Shader3D.propertyNameToID("u_freckleHsv");
	static lipstickHsv: number = Shader3D.propertyNameToID("u_lipstickHsv");
	static tatooHsv: number = Shader3D.propertyNameToID("u_tatooHsv");

	static LightInstensity: number = Shader3D.propertyNameToID("u_LightInstensity");

	static __init__(): void {

		CmShowPBRMatrial.SHADERDEFINE_SPECULARGLOSSTEXTURE = Shader3D.getDefineByName("SPECULARGLOSSTEXTURE");

		CmShowPBRMatrial.SHADERDEFINE_METALLICGLOSSTEXTURE = Shader3D.getDefineByName("METALLICGLOSSTEXTURE");

		CmShowPBRMatrial.SHADERDEFINE_SMOOTHNESSSOURCE_ALBEDOTEXTURE_ALPHA = Shader3D.getDefineByName("SMOOTHNESSSOURCE_ALBEDOTEXTURE_ALPHA");

		CmShowPBRMatrial.SHADERDEFINE_CMSPEC = Shader3D.getDefineByName("CMSPEC");

		CmShowPBRMatrial.SHADERDEFINE_MRSTEXTURE = Shader3D.getDefineByName("CMMRSTEX");
		CmShowPBRMatrial.SHADERDEFINE_FACE = Shader3D.getDefineByName("CMFACE");
		CmShowPBRMatrial.SHADERDEFINE_REL_HSV_ON = Shader3D.getDefineByName("_REL_HSV_ON");;
		CmShowPBRMatrial.SHADERDEFINE_ABS_HSV_ON = Shader3D.getDefineByName("_ABS_HSV_ON");;

		CmShowPBRMatrial.SHADERDEFINE_CMMETALLIC = Shader3D.getDefineByName("CMMETALLIC");
		CmShowPBRMatrial.SHADERDEFINE_CMROUGHNESS = Shader3D.getDefineByName("CMROUGHNESS");

		// make up 宏定义
		CmShowPBRMatrial.SHADERDEFINE_blusher = Shader3D.getDefineByName("blusher");
		CmShowPBRMatrial.SHADERDEFINE_eyelid = Shader3D.getDefineByName("eyelid");
		CmShowPBRMatrial.SHADERDEFINE_eyeline = Shader3D.getDefineByName("eyeline");
		CmShowPBRMatrial.SHADERDEFINE_eyeshadow = Shader3D.getDefineByName("eyeshadow");
		CmShowPBRMatrial.SHADERDEFINE_freckle = Shader3D.getDefineByName("freckle");
		CmShowPBRMatrial.SHADERDEFINE_lipstick = Shader3D.getDefineByName("lipstick");
		CmShowPBRMatrial.SHADERDEFINE_tatoo = Shader3D.getDefineByName("tatoo");

		CmShowPBRMatrial.SHADERDEFINE_SKINMASK = Shader3D.getDefineByName("SKINMASK");

		var attributeMap: any = {
			'a_Position': VertexMesh.MESH_POSITION0,
			'a_Normal': VertexMesh.MESH_NORMAL0,
			'a_Tangent0': VertexMesh.MESH_TANGENT0,
			'a_Texcoord0': VertexMesh.MESH_TEXTURECOORDINATE0,
			'a_Texcoord1': VertexMesh.MESH_TEXTURECOORDINATE1,
			'a_BoneWeights': VertexMesh.MESH_BLENDWEIGHT0,
			'a_BoneIndices': VertexMesh.MESH_BLENDINDICES0,
			'a_MvpMatrix': VertexMesh.MESH_MVPMATRIX_ROW0,
			'a_WorldMat': VertexMesh.MESH_WORLDMATRIX_ROW0
		};
		var uniformMap: any = {
			'u_Bones': Shader3D.PERIOD_CUSTOM,
			'u_MvpMatrix': Shader3D.PERIOD_SPRITE,
			'u_WorldMat': Shader3D.PERIOD_SPRITE,
			'u_LightmapScaleOffset': Shader3D.PERIOD_SPRITE,
			'u_LightMap': Shader3D.PERIOD_SPRITE,
			'u_LightMapDirection': Shader3D.PERIOD_SPRITE,

			'u_SimpleAnimatorTexture': Shader3D.PERIOD_SPRITE,
			'u_SimpleAnimatorParams': Shader3D.PERIOD_SPRITE,
			'u_SimpleAnimatorTextureSize': Shader3D.PERIOD_SPRITE,

			//反射
			'u_ReflectCubeHDRParams': Shader3D.PERIOD_SPRITE,
			'u_ReflectTexture': Shader3D.PERIOD_SPRITE,
			'u_SpecCubeProbePosition': Shader3D.PERIOD_SPRITE,
			'u_SpecCubeBoxMax': Shader3D.PERIOD_SPRITE,
			'u_SpecCubeBoxMin': Shader3D.PERIOD_SPRITE,

			'u_CameraPos': Shader3D.PERIOD_CAMERA,
			'u_View': Shader3D.PERIOD_CAMERA,
			'u_ProjectionParams': Shader3D.PERIOD_CAMERA,
			'u_Viewport': Shader3D.PERIOD_CAMERA,
			'u_ViewProjection': Shader3D.PERIOD_CAMERA,

			'u_AlphaTestValue': Shader3D.PERIOD_MATERIAL,
			'u_AlbedoColor': Shader3D.PERIOD_MATERIAL,
			'u_EmissionColor': Shader3D.PERIOD_MATERIAL,
			'u_AlbedoTexture': Shader3D.PERIOD_MATERIAL,
			'u_NormalTexture': Shader3D.PERIOD_MATERIAL,
			'u_ParallaxTexture': Shader3D.PERIOD_MATERIAL,
			'u_OcclusionTexture': Shader3D.PERIOD_MATERIAL,
			'u_EmissionTexture': Shader3D.PERIOD_MATERIAL,
			'u_Smoothness': Shader3D.PERIOD_MATERIAL,
			'u_SmoothnessScale': Shader3D.PERIOD_MATERIAL,
			'u_occlusionStrength': Shader3D.PERIOD_MATERIAL,
			'u_NormalScale': Shader3D.PERIOD_MATERIAL,
			'u_ParallaxScale': Shader3D.PERIOD_MATERIAL,
			'u_TilingOffset': Shader3D.PERIOD_MATERIAL,
			'u_MetallicGlossTexture': Shader3D.PERIOD_MATERIAL,
			'u_Metallic': Shader3D.PERIOD_MATERIAL,
			'u_SpecGlossTexture': Shader3D.PERIOD_MATERIAL,
			'u_SpecularColor': Shader3D.PERIOD_MATERIAL,


			'u_AmbientColor': Shader3D.PERIOD_SCENE,
			'u_FogStart': Shader3D.PERIOD_SCENE,
			'u_FogRange': Shader3D.PERIOD_SCENE,
			'u_FogColor': Shader3D.PERIOD_SCENE,
			'u_DirationLightCount': Shader3D.PERIOD_SCENE,
			'u_LightBuffer': Shader3D.PERIOD_SCENE,
			'u_LightClusterBuffer': Shader3D.PERIOD_SCENE,

			//Shadow
			'u_ShadowBias': Shader3D.PERIOD_SCENE,
			'u_ShadowLightDirection': Shader3D.PERIOD_SCENE,
			'u_ShadowMap': Shader3D.PERIOD_SCENE,
			'u_ShadowParams': Shader3D.PERIOD_SCENE,
			'u_ShadowSplitSpheres': Shader3D.PERIOD_SCENE,
			'u_ShadowMatrices': Shader3D.PERIOD_SCENE,
			'u_ShadowMapSize': Shader3D.PERIOD_SCENE,
			//SpotShadow
			'u_SpotShadowMap': Shader3D.PERIOD_SCENE,
			'u_SpotViewProjectMatrix': Shader3D.PERIOD_SCENE,
			'u_ShadowLightPosition': Shader3D.PERIOD_SCENE,

			//GI
			'u_AmbientSHAr': Shader3D.PERIOD_SCENE,
			'u_AmbientSHAg': Shader3D.PERIOD_SCENE,
			'u_AmbientSHAb': Shader3D.PERIOD_SCENE,
			'u_AmbientSHBr': Shader3D.PERIOD_SCENE,
			'u_AmbientSHBg': Shader3D.PERIOD_SCENE,
			'u_AmbientSHBb': Shader3D.PERIOD_SCENE,
			'u_AmbientSHC': Shader3D.PERIOD_SCENE,


			//legacy lighting
			'u_DirectionLight.direction': Shader3D.PERIOD_SCENE,
			'u_DirectionLight.color': Shader3D.PERIOD_SCENE,
			'u_PointLight.position': Shader3D.PERIOD_SCENE,
			'u_PointLight.range': Shader3D.PERIOD_SCENE,
			'u_PointLight.color': Shader3D.PERIOD_SCENE,
			'u_SpotLight.position': Shader3D.PERIOD_SCENE,
			'u_SpotLight.direction': Shader3D.PERIOD_SCENE,
			'u_SpotLight.range': Shader3D.PERIOD_SCENE,
			'u_SpotLight.spot': Shader3D.PERIOD_SCENE,
			'u_SpotLight.color': Shader3D.PERIOD_SCENE,

			// cm show
			'u_CMMask': Shader3D.PERIOD_MATERIAL,
			'u_hsv': Shader3D.PERIOD_MATERIAL,
			'u_disneyhsv': Shader3D.PERIOD_MATERIAL,
			'u_MRSTex': Shader3D.PERIOD_MATERIAL,
			'u_CMRoughnessTex': Shader3D.PERIOD_MATERIAL,
			'u_CMMetallicTex': Shader3D.PERIOD_MATERIAL,

			'u_LightInstensity': Shader3D.PERIOD_MATERIAL,

			// make up
			"u_blusher": Shader3D.PERIOD_MATERIAL,
			"u_eyelid": Shader3D.PERIOD_MATERIAL,
			"u_eyeline": Shader3D.PERIOD_MATERIAL,
			"u_eyeshadow": Shader3D.PERIOD_MATERIAL,
			"u_freckle": Shader3D.PERIOD_MATERIAL,
			"u_lipstick": Shader3D.PERIOD_MATERIAL,
			"u_tatoo": Shader3D.PERIOD_MATERIAL,

			"u_blusherVec": Shader3D.PERIOD_MATERIAL,
			"u_eyelidVec": Shader3D.PERIOD_MATERIAL,
			"u_eyelineVec": Shader3D.PERIOD_MATERIAL,
			"u_eyeshadowVec": Shader3D.PERIOD_MATERIAL,
			"u_freckleVec": Shader3D.PERIOD_MATERIAL,
			"u_lipstickVec": Shader3D.PERIOD_MATERIAL,
			"u_tatooVec": Shader3D.PERIOD_MATERIAL,

			"u_blusherHsv": Shader3D.PERIOD_MATERIAL,
			"u_eyelidHsv": Shader3D.PERIOD_MATERIAL,
			"u_eyelineHsv": Shader3D.PERIOD_MATERIAL,
			"u_eyeshadowHsv": Shader3D.PERIOD_MATERIAL,
			"u_freckleHsv": Shader3D.PERIOD_MATERIAL,
			"u_lipstickHsv": Shader3D.PERIOD_MATERIAL,
			"u_tatooHsv": Shader3D.PERIOD_MATERIAL,
		};
		var stateMap = {
			's_Cull': Shader3D.RENDER_STATE_CULL,
			's_Blend': Shader3D.RENDER_STATE_BLEND,
			's_BlendSrc': Shader3D.RENDER_STATE_BLEND_SRC,
			's_BlendDst': Shader3D.RENDER_STATE_BLEND_DST,
			's_DepthTest': Shader3D.RENDER_STATE_DEPTH_TEST,
			's_DepthWrite': Shader3D.RENDER_STATE_DEPTH_WRITE
		}
		var shader: Shader3D = Shader3D.add("CMPBR", attributeMap, uniformMap, true, true);
		var subShader: SubShader = new SubShader(attributeMap, uniformMap);
		shader.addSubShader(subShader);
		subShader.addShaderPass(CMPBRVS, CMPBRPS, stateMap, "Forward");
		subShader.addShaderPass(CMPBRShadowCasterVS, CMPBRShadowCasterPS, stateMap, "ShadowCaster");
	}

	/** @internal */
	private _smoothnessSource: PBRMetallicSmoothnessSource | PBRSpecularSmoothnessSource = 0;

	/**
	 * 附加光照强度
	 */
	get lightInstensity(): number {
		return this._shaderValues.getNumber(CmShowPBRMatrial.LightInstensity);
	}

	set lightInstensity(value: number) {
		this._shaderValues.setNumber(CmShowPBRMatrial.LightInstensity, Math.max(0, value));
	}

	/**
	 * 高光颜色。
	 */
	get specularColor(): Vector4 {
		return <Vector4>this._shaderValues.getVector(CmShowPBRMatrial.SPECULARCOLOR);
	}

	set specularColor(value: Vector4) {
		this._shaderValues.setVector(CmShowPBRMatrial.SPECULARCOLOR, value);
	}

	/**
	 * 高光贴图。
	 */
	get specularTexture(): BaseTexture {
		return this._shaderValues.getTexture(CmShowPBRMatrial.SPECULARTEXTURE);
	}

	/**
 * 金属光滑度贴图。
 */
	get metallicGlossTexture(): BaseTexture {
		return this._shaderValues.getTexture(CmShowPBRMatrial.METALLICGLOSSTEXTURE);
	}

	set metallicGlossTexture(value: BaseTexture) {
		if (value)
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_METALLICGLOSSTEXTURE);
		else
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_METALLICGLOSSTEXTURE);

		this._shaderValues.setTexture(CmShowPBRMatrial.METALLICGLOSSTEXTURE, value);
	}

	/**
	 * 获取金属度,范围为0到1。
	 */
	get metallic(): number {
		return this._shaderValues.getNumber(CmShowPBRMatrial.METALLIC);
	}

	set metallic(value: number) {
		this._shaderValues.setNumber(CmShowPBRMatrial.METALLIC, Math.max(0.0, Math.min(1.0, value)));
	}

	/**
	 * 光滑度数据源,0或1。
	 */
	get smoothnessSource(): PBRMetallicSmoothnessSource | PBRSpecularSmoothnessSource {
		return this._smoothnessSource;
	}

	set smoothnessSource(value: PBRMetallicSmoothnessSource | PBRSpecularSmoothnessSource) {
		if (value)
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_SMOOTHNESSSOURCE_ALBEDOTEXTURE_ALPHA);
		else
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_SMOOTHNESSSOURCE_ALBEDOTEXTURE_ALPHA);
		this._smoothnessSource = value;
	}

	set specularTexture(value: BaseTexture) {
		if (value)
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_SPECULARGLOSSTEXTURE);
		else
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_SPECULARGLOSSTEXTURE);
		this._shaderValues.setTexture(CmShowPBRMatrial.SPECULARTEXTURE, value);
	}

	get MRSTexture(): BaseTexture {
		return this._shaderValues.getTexture(CmShowPBRMatrial.CMMRSTEX);
	}

	set MRSTexture(value: BaseTexture) {
		if (value)
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_MRSTEXTURE);
		else
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_MRSTEXTURE);
		this._shaderValues.setTexture(CmShowPBRMatrial.CMMRSTEX, value);
	}

	get skinMask(): BaseTexture {
		return this._shaderValues.getTexture(CmShowPBRMatrial.CMMASK);
	}

	set skinMask(value: BaseTexture) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_SKINMASK);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_SKINMASK);
		}
		this._shaderValues.setTexture(CmShowPBRMatrial.CMMASK, value);
	}

	get skinHSV(): Vector3 {
		return this._shaderValues.getVector3(CmShowPBRMatrial.CMSHVL);
	}

	set skinHSV(value: Vector3) {
		this._shaderValues.setVector3(CmShowPBRMatrial.CMSHVL, value);
	}

	set isSpecular(value: boolean) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_CMSPEC);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_CMSPEC);
		}
	}

	set _REL_HSV_ON(value: boolean) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_REL_HSV_ON);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_REL_HSV_ON);
		}
	}

	set _ABS_HSV_ON(value: boolean) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_ABS_HSV_ON);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_ABS_HSV_ON);
		}
	}

	set cmFace(value: boolean) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_FACE);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_FACE);
		}
	}

	get disneyHSV(): Vector3 {
		return this._shaderValues.getVector3(CmShowPBRMatrial.CMDISNEYSHVL);
	}
	set disneyHSV(value: Vector3) {
		this._shaderValues.setVector3(CmShowPBRMatrial.CMDISNEYSHVL, value);
	}

	set CMMetallic(value: BaseTexture) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_CMMETALLIC);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_CMMETALLIC);
		}
		this._shaderValues.setTexture(CmShowPBRMatrial.CMMetallic, value);
	}

	set CMRoughness(value: BaseTexture) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_CMROUGHNESS);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_CMROUGHNESS);
		}
		this._shaderValues.setTexture(CmShowPBRMatrial.CMRoughness, value);
	}




	constructor() {
		super();
		this.setShaderName("CMPBR");
		this._shaderValues.setNumber(CmShowPBRMatrial.METALLIC, 0.0);
		this._shaderValues.setVector(CmShowPBRMatrial.SPECULARCOLOR, new Vector4(0.2, 0.2, 0.2, 1.0))
		this._shaderValues.setNumber(CmShowPBRMatrial.LightInstensity, 1.0);
		this._shaderValues.setVector3(CmShowPBRMatrial.CMSHVL, new Vector3(0, 0, 0));
	}

	// make up parts
	// blusher
	get blusher(): BaseTexture {
		return this._shaderValues.getTexture(CmShowPBRMatrial.blusher);
	}
	set blusher(value: BaseTexture) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_blusher);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_blusher);
		}
		this._shaderValues.setTexture(CmShowPBRMatrial.blusher, value);
	}

	get blusherVec(): Vector4 {
		return this._shaderValues.getVector(CmShowPBRMatrial.blusherVec);
	}

	set blusherVec(value: Vector4) {
		this._shaderValues.setVector(CmShowPBRMatrial.blusherVec, value);
	}

	get blusherHsv(): Vector3 {
		return this._shaderValues.getVector3(CmShowPBRMatrial.blusherHsv);
	}

	set blusherHsv(value: Vector3) {
		this._shaderValues.setVector3(CmShowPBRMatrial.blusherHsv, value);
	}

	// eyelid
	get eyelid(): BaseTexture {
		return this._shaderValues.getTexture(CmShowPBRMatrial.eyelid);
	}
	set eyelid(value: BaseTexture) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_eyelid);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_eyelid);
		}
		this._shaderValues.setTexture(CmShowPBRMatrial.eyelid, value);
	}

	get eyelidVec(): Vector4 {
		return this._shaderValues.getVector(CmShowPBRMatrial.eyelidVec);
	}

	set eyelidVec(value: Vector4) {
		this._shaderValues.setVector(CmShowPBRMatrial.eyelidVec, value);
	}

	get eyelidHsv(): Vector3 {
		return this._shaderValues.getVector3(CmShowPBRMatrial.eyelidHsv);
	}

	set eyelidHsv(value: Vector3) {
		this._shaderValues.setVector3(CmShowPBRMatrial.eyelidHsv, value);
	}

	// eyeline
	get eyeline(): BaseTexture {
		return this._shaderValues.getTexture(CmShowPBRMatrial.eyeline);
	}
	set eyeline(value: BaseTexture) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_eyeline);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_eyeline);
		}
		this._shaderValues.setTexture(CmShowPBRMatrial.eyeline, value);
	}

	get eyelineVec(): Vector4 {
		return this._shaderValues.getVector(CmShowPBRMatrial.eyelineVec);
	}

	set eyelineVec(value: Vector4) {
		this._shaderValues.setVector(CmShowPBRMatrial.eyelineVec, value);
	}

	get eyelineHsv(): Vector3 {
		return this._shaderValues.getVector3(CmShowPBRMatrial.eyelineHsv);
	}

	set eyelineHsv(value: Vector3) {
		this._shaderValues.setVector3(CmShowPBRMatrial.eyelineHsv, value);
	}

	// eyeshadow
	get eyeshadow(): BaseTexture {
		return this._shaderValues.getTexture(CmShowPBRMatrial.eyeshadow);
	}
	set eyeshadow(value: BaseTexture) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_eyeshadow);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_eyeshadow);
		}
		this._shaderValues.setTexture(CmShowPBRMatrial.eyeshadow, value);
	}

	get eyeshadowVec(): Vector4 {
		return this._shaderValues.getVector(CmShowPBRMatrial.eyeshadowVec);
	}

	set eyeshadowVec(value: Vector4) {
		this._shaderValues.setVector(CmShowPBRMatrial.eyeshadowVec, value);
	}

	get eyeshadowHsv(): Vector3 {
		return this._shaderValues.getVector3(CmShowPBRMatrial.eyeshadowHsv);
	}

	set eyeshadowHsv(value: Vector3) {
		this._shaderValues.setVector3(CmShowPBRMatrial.eyeshadowHsv, value);
	}

	// freckle
	get freckle(): BaseTexture {
		return this._shaderValues.getTexture(CmShowPBRMatrial.freckle);
	}
	set freckle(value: BaseTexture) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_freckle);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_freckle);
		}
		this._shaderValues.setTexture(CmShowPBRMatrial.freckle, value);
	}

	get freckleVec(): Vector4 {
		return this._shaderValues.getVector(CmShowPBRMatrial.freckleVec);
	}

	set freckleVec(value: Vector4) {
		this._shaderValues.setVector(CmShowPBRMatrial.freckleVec, value);
	}

	get freckleHsv(): Vector3 {
		return this._shaderValues.getVector3(CmShowPBRMatrial.freckleHsv);
	}

	set freckleHsv(value: Vector3) {
		this._shaderValues.setVector3(CmShowPBRMatrial.freckleHsv, value);
	}

	// lipstick
	get lipstick(): BaseTexture {
		return this._shaderValues.getTexture(CmShowPBRMatrial.lipstick);
	}
	set lipstick(value: BaseTexture) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_lipstick);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_lipstick);
		}
		this._shaderValues.setTexture(CmShowPBRMatrial.lipstick, value);
	}

	get lipstickVec(): Vector4 {
		return this._shaderValues.getVector(CmShowPBRMatrial.lipstickVec);
	}

	set lipstickVec(value: Vector4) {
		this._shaderValues.setVector(CmShowPBRMatrial.lipstickVec, value);
	}

	get lipstickHsv(): Vector3 {
		return this._shaderValues.getVector3(CmShowPBRMatrial.lipstickHsv);
	}

	set lipstickHsv(value: Vector3) {
		this._shaderValues.setVector3(CmShowPBRMatrial.lipstickHsv, value);
	}

	// tatoo
	get tatoo(): BaseTexture {
		return this._shaderValues.getTexture(CmShowPBRMatrial.tatoo);
	}
	set tatoo(value: BaseTexture) {
		if (value) {
			this._shaderValues.addDefine(CmShowPBRMatrial.SHADERDEFINE_tatoo);
		}
		else {
			this._shaderValues.removeDefine(CmShowPBRMatrial.SHADERDEFINE_tatoo);
		}
		this._shaderValues.setTexture(CmShowPBRMatrial.tatoo, value);
	}

	get tatooVec(): Vector4 {
		return this._shaderValues.getVector(CmShowPBRMatrial.tatooVec);
	}

	set tatooVec(value: Vector4) {
		this._shaderValues.setVector(CmShowPBRMatrial.tatooVec, value);
	}

	get tatooHsv(): Vector3 {
		return this._shaderValues.getVector3(CmShowPBRMatrial.tatooHsv);
	}

	set tatooHsv(value: Vector3) {
		this._shaderValues.setVector3(CmShowPBRMatrial.tatooHsv, value);
	}

	clone(): any {
		var dest: CmShowPBRMatrial = new CmShowPBRMatrial();
		this.cloneTo(dest);
		return dest;
	}
}