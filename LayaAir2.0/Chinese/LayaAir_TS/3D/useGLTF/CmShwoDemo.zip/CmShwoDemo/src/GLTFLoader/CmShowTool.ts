import { CmShowPBRMatrial } from "./CmShowPBRMatrial";
import GLTFLoader = Laya.GLTFLoader;
import Handler = Laya.Handler;
import Sprite3D = Laya.Sprite3D;
import Loader = Laya.Loader;
import RenderableSprite3D = Laya.RenderableSprite3D;
import SkinnedMeshSprite3D = Laya.SkinnedMeshSprite3D;
import SkinnedMeshRenderer = Laya.SkinnedMeshRenderer;
import Animator = Laya.Animator;
import AnimationClip = Laya.AnimationClip;
import AnimatorControllerLayer = Laya.AnimatorControllerLayer;
import AnimatorState = Laya.AnimatorState;
import Vector3 = Laya.Vector3;
import Vector4 = Laya.Vector4;
import Texture2D = Laya.Texture2D;
import Vector2 = Laya.Vector2;
import WarpMode = Laya.WarpMode;
import MeshSprite3D = Laya.MeshSprite3D;

export class CmShowCharacterStruct {
    gltfURL: any;
    customConfigURL: any;
    makeupConfigURL: any;
    extraRes: any[] = [];
}

/**
 * 部件对应 hsv 取值属性
 */
const asssociatedHSV = {
    top_q: "skin",
    top: "skin",
    top_app: "skin",

    bottom_q: "skin",
    bottom: "skin",
    bottom_app: "skin",

    face: "skin",
    foot: "skin",
    hair: "hair",

    eyebrow_q: "eyebrow",  //眼眉毛
    eyebrow: "eyebrow",  //眼眉毛
    eyebrow_app: "eyebrow",  //眼眉毛

    eyelash_q: "eyelash",   //睫毛
    eyelash: "eyelash",   //睫毛
    eyelash_app: "eyelash",   //睫毛
    hair_app: "hair",   //头发
    hair_q: "hair",   //头发
};

export class CmShowTool {
    // 初始化函数
    static init() {
        // 初始化 厘米秀材质
        CmShowPBRMatrial.__init__();
    }

    constructor() {

    }

    /**
     * 加载厘米秀模型
     * @param struct 辅助加载对象
     * @param complete 回调函数函数
     */

    static LoadCharacter(struct: CmShowCharacterStruct, complete?: Handler) {

        struct.extraRes || (struct.extraRes = []);
        struct.customConfigURL && (struct.extraRes.push(struct.customConfigURL));
        for (const key in struct.makeupConfigURL) {
            var makePart: any = struct.makeupConfigURL[key];
            struct.extraRes.push(makePart.cfg);
            struct.extraRes.push(makePart.tex);
        }

        if (struct.extraRes.length > 0) {
            var extraHandle: Handler = Handler.create(this, function (success: boolean) {
                if (!success) {
                    // todo 附加资源加载失败
                }
                CmShowTool.LoadGLTF(struct, complete);
            });
            Laya.loader.create(struct.extraRes, extraHandle);
        }
        else {
            CmShowTool.LoadGLTF(struct, complete);
        }

    }

    static LoadGLTF(struct: CmShowCharacterStruct, complete?: Handler) {

        // 组织 gltf 模型资源路径
        var urls: any = struct.gltfURL;
        var loadArray: any[] = [];
        for (const key in urls) {
            loadArray.push(urls[key]);
        }

        // 实例化 loader
        var gltfLoader: GLTFLoader = new GLTFLoader();
        // 默认材质
        GLTFLoader.defaultMatrial = new CmShowPBRMatrial();
        // 添加 cmshow mesh extra 解析
        // 用于还原 外部文件中 脸型数据
        gltfLoader.extraFunc.meshExtras = function (gltfmesh) {
            return function () {

                var customCfg = Loader.getRes(struct.customConfigURL);
                if (!customCfg) return;

                var blendshape = customCfg.blendshape;
                if (gltfmesh.extras.targetNames) {
                    var targetNames: string[] = gltfmesh.extras.targetNames;

                    for (const key in blendshape) {
                        var wi: number = targetNames.indexOf(key);
                        gltfmesh.weights[wi] = blendshape[key];
                    }
                }
            }
        };
        // 解析 material
        // 用于还原 厘米秀自定义材质属性
        gltfLoader.extraFunc.materialExtras = function (gltfLoader: GLTFLoader, gltfMaterial, mat: CmShowPBRMatrial) {

            var extras = gltfMaterial.extras;

            for (const key in extras) {
                var extra = extras[key];
                if (key == "Cmshow_UnityPBS") {
                    var specularColor: Vector4 = mat.specularColor;
                    extra.specular && specularColor.fromArray(extra.specular);
                    //@ts-ignore
                    mat.skinMask = gltfLoader.gltfGetTextureWithInfo(extra.skinMaskTexture);
                    mat.isSpecular = true;
                }
                else if (key == "Cmshow_Disney") {
                    mat.isSpecular = false;
                    //@ts-ignore
                    mat.skinMask = gltfLoader.gltfGetTextureWithInfo(extra.skinMaskTexture);
                    //@ts-ignore
                    mat.MRSTexture = gltfLoader.gltfGetTextureWithInfo(extra.metallicRoughnessSpecTexture);
                    //@ts-ignore
                    mat.CMMetallic = gltfLoader.gltfGetTextureWithInfo(extra.metallicTexture);
                    //@ts-ignore
                    mat.CMRoughness = gltfLoader.gltfGetTextureWithInfo(extra.roughnessTexture);
                    mat._ABS_HSV_ON = extra._ABS_HSV_ON;
                    mat._REL_HSV_ON = extra._REL_HSV_ON;
                    if (extra._ABS_HSV_ON) {
                        var disneyHSV: Vector3 = new Vector3();
                        disneyHSV.x = extra._Hue / 360;
                        disneyHSV.y = extra._Saturate / 100;
                        disneyHSV.z = extra._Value / 100;
                        mat.disneyHSV = disneyHSV;
                    }
                }
            }
            return function () { }
        }

        // 加载 模型资源
        gltfLoader.loadGLTF(loadArray, Handler.create(this, CmShowTool.loadGLTFDone, [struct, complete]));
    }


    /**
     * 模型资源加载完成后拼装成整个人物
     * @param struct 辅助加载对象
     * @param complete 回调函数
     * @param success 是否加载成功
     */
    static loadGLTFDone(struct: CmShowCharacterStruct, complete: Handler = null, success: boolean) {
        if (!success) {
            // todo 加载失败
            console.log("load fail");
            return;
        }

        // 模型骨骼数据根节点
        var skeletonRoot: Sprite3D = GLTFLoader.getRes(struct.gltfURL.skeleton.url);
        var animatorRootName: string = "Group";
        // 此处 animatorRoot 节点 为 unity 中 Animator 组件所在节点
        var animatorRoot: Sprite3D = CmShowTool.getAnimatorRoot(skeletonRoot, animatorRootName);
        // 记录每一部分的 Animator root 节点
        var partAnimatorRootArray: Array<Sprite3D> = new Array();
        // 记录每一部分的 渲染节点
        var renderableMap: Map<string, Array<RenderableSprite3D>> = new Map();

        for (const key in struct.gltfURL) {
            /**
             * 厘米秀人物每一部分 gltf 文件中包含这个部分的渲染节点与人物全部的骨骼节点
             * 解析完 gltf 后， 将每一部分渲染节点抽出， 拼装到一套骨骼节点中
             * 方便后续添加动画
             */
            var part: Sprite3D = GLTFLoader.getRes(struct.gltfURL[key].url);
            var renderableArray: RenderableSprite3D[] = CmShowTool.selectRenderableSprite(part);

            var partAnimatorRoot: Sprite3D = CmShowTool.getAnimatorRoot(part, animatorRootName);
            partAnimatorRootArray.push(partAnimatorRoot);

            renderableMap.set(key, renderableArray);

            var customCfg = Loader.getRes(struct.customConfigURL);
            if (!customCfg)
                continue;

            var isface: boolean = key == "face";

            var lightInstensity: number = 1.0;
            if (asssociatedHSV[key]) {
                // 读取自定义配置文件中数据， 更改肤色
                var deltaHSV = customCfg.deltaHSV;
                var hsvkey: string = asssociatedHSV[key];
                var hsv: Vector3 = new Vector3(deltaHSV[hsvkey].H / 360, deltaHSV[hsvkey].S / 100, deltaHSV[hsvkey].V / 100);
                renderableArray.forEach(sprite => {
                    if (sprite.name == key) {
                        if (sprite instanceof MeshSprite3D) {
                            var materials: CmShowPBRMatrial[] = <CmShowPBRMatrial[]>sprite.meshRenderer.sharedMaterials;
                        }
                        else if (sprite instanceof SkinnedMeshSprite3D) {
                            var materials: CmShowPBRMatrial[] = <CmShowPBRMatrial[]>sprite.skinnedMeshRenderer.sharedMaterials;
                        }
                        materials.forEach(mat => {
                            mat.skinHSV = hsv;
                            mat.cmFace = isface;
                            mat.lightInstensity = lightInstensity;
                        });
                    }
                });
            }
        }
        // 创建骨骼map
        var skeletonMap: Map<string, Sprite3D> = CmShowTool.buildSkeletonMap(skeletonRoot, partAnimatorRootArray);

        // 提取 渲染节点， 添加到骨骼框架中
        // 重绑定 skinnedsprite3d 关联的骨骼节点
        renderableMap.forEach(renderableArray => {

            CmShowTool.reBindBones(renderableArray, skeletonMap);
            renderableArray.forEach((sprite) => {
                sprite.removeChildren();
                animatorRoot.addChild(sprite);
                if (sprite instanceof SkinnedMeshSprite3D) {
                    // 重新计算包围盒
                    // SkinnedMeshSprite3D 包围盒受根骨骼世界坐标影响， 因为抽取重装SkinnedMeshSprite3D， 根骨骼位置可能改变，安全起见重算包围盒， 若能保证根骨骼坐标一致， 可省略计算
                    //@ts-ignore
                    GLTFLoader.calSkinnedSpriteLocalBounds(sprite);
                }
            });
        });

        // 添加 Animator
        CmShowTool.addAniamtor(animatorRoot, renderableMap, skeletonMap);

        // 可选择是否应用 makeup 装扮
        // 获取脸部节点列表
        var faceRenderableArray: Array<RenderableSprite3D> = renderableMap.get("face");
        CmShowTool.applyFaceMakeUp(faceRenderableArray, struct);

        // 加载出的模型大小固定， 自行调整缩放适应
        skeletonRoot.transform.setWorldLossyScale(new Vector3(0.01, 0.01, 0.01));
        // 执行回调
        complete && complete.runWith([skeletonRoot, renderableMap]);

    }

    /**
     * 获取 Animator 根节点
     * 返回 节点 为 unity 中 Animator 组件所在节点
     * @param root 
     */
    static getAnimatorRoot(root: Sprite3D, rootName: string): Sprite3D {

        var sprite: Sprite3D = <Sprite3D>root.getChildByName(rootName);
        if (sprite) {
            return sprite;
        }
        else {
            for (let index = 0; index < root.numChildren; index++) {
                var child: Sprite3D = <Sprite3D>root.getChildAt(index);
                return CmShowTool.getAnimatorRoot(child, rootName);
            }
        }
        return null;

    }

    /**
     * 添加根 Aniamtor 组件
     * @param animatorRoot 根节点，在此节点上添加 Animator 组件
     * @param partsRenderableArray 各部分渲染节点数组
     * @param skeletonMap 骨骼map
     */
    static addAniamtor(animatorRoot: Sprite3D, renderableMap: Map<string, Array<RenderableSprite3D>>, skeletonMap: Map<string, Sprite3D>) {
        var animator: Animator = animatorRoot.addComponent(Animator);

        // animator 添加 渲染节点 队列
        renderableMap.forEach(renderableArray => {
            //@ts-ignore
            animator._renderableSprites.push(...renderableArray);
        });

        // 添加 animator clip
        // 在 Unity 中使用默认骨骼导出动画数据
        var clip: AnimationClip = Loader.getRes("res/gltfMode/Aniamtor/dalaozuo-dalaozuo.lani");
        if (!clip)
            return;

        var layer: AnimatorControllerLayer = new AnimatorControllerLayer("test");
        var animatorState: AnimatorState = new AnimatorState();
        animatorState.clip = clip;
        layer.addState(animatorState);
        layer.defaultState = animatorState;
        layer.playOnWake = true;
        animator.addControllerLayer(layer);
        layer.defaultWeight = 1.0;
    }

    /**
     * 根据骨骼资源 gltf 创建骨骼节点map
     * @param skeletonRoot 
     */
    static buildSkeletonMap(skeletonRoot: Sprite3D, partAnimatorRootArray: Array<Sprite3D>): Map<string, Sprite3D> {
        var boneMap: Map<string, Sprite3D> = new Map();

        var childHandle = function (sprite: Sprite3D) {
            for (let index = 0; index < sprite.numChildren; index++) {
                let child: Sprite3D = <Sprite3D>sprite.getChildAt(index);
                boneMap.set(child.name, child);
                childHandle(child);
            }
        }

        childHandle(skeletonRoot);

        var mergeBoneHandle = function (sprite: Sprite3D, addedBoneArray: Array<Sprite3D>) {

            for (let index = 0; index < sprite.numChildren; index++) {
                let child: Sprite3D = <Sprite3D>sprite.getChildAt(index);
                let name: string = child.name;
                if (!boneMap.has(name)) {
                    addedBoneArray.push(child);
                }
                mergeBoneHandle(child, addedBoneArray);
            }
        }
        partAnimatorRootArray.forEach(partAnimatorRoot => {
            var addedBoneArray: Array<Sprite3D> = new Array();
            mergeBoneHandle(partAnimatorRoot, addedBoneArray);
            addedBoneArray.forEach(addedBone => {
                var parent: Sprite3D = boneMap.get(addedBone.parent.name);
                parent.addChild(addedBone);
                boneMap.set(addedBone.name, addedBone);
            });
        });

        return boneMap;
    }

    /**
     * 提取渲染节点
     * @param root 
     * @return RenderableSprite3D[] 渲染节点列表
     */
    static selectRenderableSprite(root: Sprite3D): RenderableSprite3D[] {
        var renderableSpriteArray: RenderableSprite3D[] = [];

        var cheackRenderable = function (sprite: Sprite3D) {
            for (let index = 0; index < sprite.numChildren; index++) {
                let child: Sprite3D = <Sprite3D>sprite.getChildAt(index);
                if (child instanceof RenderableSprite3D) {
                    renderableSpriteArray.push(child);
                }
                cheackRenderable(child);
            }
        }
        cheackRenderable(root);
        return renderableSpriteArray;
    }

    /**
     * 根据骨骼map， 将渲染节点重绑定到新的骨骼中
     * @param renderableSpriteArray 
     * @param skeletonMap 
     */
    static reBindBones(renderableSpriteArray: Sprite3D[], skeletonMap: Map<string, Sprite3D>) {
        renderableSpriteArray.forEach((sprite, index) => {
            if (sprite instanceof SkinnedMeshSprite3D) {
                var render: SkinnedMeshRenderer = sprite.skinnedMeshRenderer;
                render.rootBone = skeletonMap.get(render.rootBone.name);
                for (let index = 0; index < render.bones.length; index++) {
                    var name: string = render.bones[index].name;
                    render.bones[index] = skeletonMap.get(name);
                }
            }
        });
    }

    /**
     * 应用makeup装扮
     * @param faceRenderableArray 
     * @param struct 
     */
    static applyFaceMakeUp(faceRenderableArray: RenderableSprite3D[], struct: any) {
        var makeupConfigURL = struct.makeupConfigURL;
        var customConfig = Loader.getRes(struct.customConfigURL);
        if (!(makeupConfigURL && customConfig)) {
            return;
        }

        var deltaHSV = customConfig.deltaHSV;
        for (const key in makeupConfigURL) {
            var json: any = makeupConfigURL[key].cfg;
            var partjson = Loader.getRes(json);

            var texurl: string = makeupConfigURL[key].tex;
            var partTex: Texture2D = Loader.getRes(texurl);
            if (!partTex)
                continue;
            partTex.wrapModeU = WarpMode.Clamp;
            partTex.wrapModeV = WarpMode.Clamp;

            var partVec: Vector4 = new Vector4(0, 0, 1, 1);
            var partHsv: Vector3 = new Vector3();

            if (deltaHSV[key]) {
                partHsv.setValue(deltaHSV[key].H / 360, deltaHSV[key].S / 100, deltaHSV[key].V / 100);
            }

            var currentPosition: Vector2 = new Vector2(partjson.cropping[0], partjson.cropping[1]);
            var originSize: Vector2 = new Vector2(partjson.originSize[0], partjson.originSize[1]);
            partVec.x = currentPosition.x / originSize.x;
            partVec.y = (originSize.y - (currentPosition.y + partTex.height)) / originSize.y;
            partVec.z = partTex.width / originSize.x;
            partVec.w = partTex.height / originSize.y;

            faceRenderableArray.forEach(sprite => {
                var materials: CmShowPBRMatrial[];
                if (sprite instanceof MeshSprite3D) {
                    materials = <CmShowPBRMatrial[]>sprite.meshRenderer.sharedMaterials;
                }
                else if (sprite instanceof SkinnedMeshSprite3D) {
                    materials = <CmShowPBRMatrial[]>sprite.skinnedMeshRenderer.sharedMaterials;
                }
                materials.forEach(mat => {
                    var cmMat: CmShowPBRMatrial = <CmShowPBRMatrial>mat;
                    cmMat[key] = partTex;
                    cmMat[key + "Vec"] = partVec;
                    cmMat[key + "Hsv"] = partHsv;
                });
            });
        }
    }

}