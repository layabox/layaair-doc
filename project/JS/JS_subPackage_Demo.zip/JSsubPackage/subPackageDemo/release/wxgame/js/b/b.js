// 显示A页
function showA()
{
    //放到window里的方法，取的时候也要用window取
   window.showUI(window.aUI,window.UI)


    //监听按钮btnA的点击事件，触发后处理
    window.UI.btnA.on(Laya.Event.CLICK, this, window.showB);
}

//其它包里要使用的方法，也必须放到window里
window.showA = showA;