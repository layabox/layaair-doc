
var UI  = null;

//微信小游戏库初始化
Laya.MiniAdpter.init();

//引擎初始化
Laya.init(0, 0, Laya.WebGL);

//屏幕适配模式
Laya.stage.scaleMode = "full";

//加载图集
Laya.loader.load("res/atlas/comp.atlas", Laya.Handler.create(this, onLoaded));

//显示UI切换界面的通用函数
function showUI(UIname,delUI)
{
    if(delUI != null)
            delUI.removeSelf();//删除指定UI
    
    //实例化新的UI
    UI = new UIname();

    //把实例化的UI放到window域，分包的必须
    window.UI = UI;

    //添加UI在舞台
    Laya.stage.addChild(UI);

}

//图集加载后回调
function onLoaded()
{
   showUI(aUI);
   
   const loadTask = wx.loadSubpackage({
        name: 'b', // name 可以填 name 或者 root
        success: function(res) {
            // 分包加载成功后通过 success 回调
            console.log("success");
            //监听按钮btnA的点击事件，触发后处理
             UI.btnA.on(Laya.Event.CLICK, this, showB);
        },
        fail: function(res) {
            // 分包加载失败通过 fail 回调
            console.log("fail");
        }
    })
    
}

//显示B页
function showB()
{
    
    showUI(bUI,UI)
 
    //监听按钮btnB的点击事件，触发后处理
    UI.btnB.on(Laya.Event.CLICK, this, window.showA);
}

//把需要被分包中使用的放到window域里
window.showB = showB;
window.showUI = showUI;
window.aUI = aUI;
