var UI  = null;

//初始化微信小游戏
Laya.MiniAdpter.init();

Laya.init(0, 0, Laya.WebGL);

Laya.stage.scaleMode = "full";

//加载图集
Laya.loader.load("res/atlas/comp.atlas", Laya.Handler.create(this, onLoaded));

//显示UI切换界面的通用函数
function showUI(UIname,delUI)
{
    if(delUI != null)
            delUI.removeSelf();//删除指定UI
    
     //实例化新的UI
    UI = new UIname();

    //添加UI在舞台
    Laya.stage.addChild(UI);
}

//图集加载后回调
function onLoaded()
{
   showUI(aUI);
    //监听按钮btnA的点击事件，触发后处理
    UI.btnA.on(Laya.Event.CLICK, this, showB);
    
}

//显示B页
function showB()
{
    showUI(bUI,UI)

    //监听按钮btnB的点击事件，触发后处理
    UI.btnB.on(Laya.Event.CLICK, this, showA);
}


//显示A页
function showA()
{
   showUI(aUI,UI)
   
    //监听按钮btnA的点击事件，触发后处理
    UI.btnA.on(Laya.Event.CLICK, this, showB);
}
