var CLASS$=Laya.class;
var STATICATTR$=Laya.static;
var View=laya.ui.View;
var Dialog=laya.ui.Dialog;
var aUI=(function(_super){
		function aUI(){
			
		    this.btnA=null;

			aUI.__super.call(this);
		}

		CLASS$(aUI,'ui.aUI',_super);
		var __proto__=aUI.prototype;
		__proto__.createChildren=function(){
		    
			laya.ui.Component.prototype.createChildren.call(this);
			this.createView(aUI.uiView);

		}

		aUI.uiView={"type":"View","props":{"width":600,"height":400},"child":[{"type":"Button","props":{"y":180,"x":177,"width":211,"var":"btnA","skin":"comp/button.png","sizeGrid":"5,10,8,8","labelSize":30,"label":"跳转到B","height":98}},{"type":"Label","props":{"y":77,"x":165,"width":141,"text":"我是A页面","height":35,"fontSize":50,"color":"#f9f8f8","bold":true}}]};
		return aUI;
	})(View);
var bUI=(function(_super){
		function bUI(){
			
		    this.btnB=null;

			bUI.__super.call(this);
		}

		CLASS$(bUI,'ui.bUI',_super);
		var __proto__=bUI.prototype;
		__proto__.createChildren=function(){
		    
			laya.ui.Component.prototype.createChildren.call(this);
			this.createView(bUI.uiView);

		}

		bUI.uiView={"type":"View","props":{"width":600,"height":400},"child":[{"type":"Label","props":{"y":65,"x":175,"width":141,"text":"我是B页面","height":35,"fontSize":50,"color":"#ffff16","bold":true}},{"type":"Button","props":{"y":181,"x":187,"width":211,"var":"btnB","skin":"comp/button.png","sizeGrid":"5,10,8,8","labelSize":30,"label":"跳转到A","height":98}}]};
		return bUI;
	})(View);