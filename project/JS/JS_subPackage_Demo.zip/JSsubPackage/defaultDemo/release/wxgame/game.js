require("weapp-adapter.js");
require("./code.js");