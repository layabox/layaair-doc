
(function(window,document,Laya){
	var __un=Laya.un,__uns=Laya.uns,__static=Laya.static,__class=Laya.class,__getset=Laya.getset,__newvec=Laya.__newvec;

	var Event=laya.events.Event,a=Laya.a,aUI=ui.aUI,bUI=ui.bUI;
//class subpackage.b
var b=(function(){
	function b(){}
	__class(b,'subpackage.b');
	var __proto=b.prototype;
	__proto.init=function(){
		a.newUI.btnA.on("click",this,this.showB);
	}

	//显示B页
	__proto.showB=function(){
		a.showUI(bUI,a.newUI)
		a.newUI.btnB.on("click",this,this.showA);
	}

	//显示A页
	__proto.showA=function(){
		a.showUI(aUI,a.newUI)
		a.newUI.btnA.on("click",this,this.showB);
	}

	return b;
})()



})(window,document,Laya);

if (typeof define === 'function' && define.amd){
	define('laya.core', ['require', "exports"], function(require, exports) {
        'use strict';
        Object.defineProperty(exports, '__esModule', { value: true });
        for (var i in Laya) {
			var o = Laya[i];
            o && o.__isclass && (exports[i] = o);
        }
    });
}